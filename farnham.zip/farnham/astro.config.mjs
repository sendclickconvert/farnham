import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';
import sitemap from '@astrojs/sitemap';
import node from '@astrojs/node';
import react from '@astrojs/react';

// TODO: CONFIRM final production domain with client, then update here + in src/data/site.ts
export default defineConfig({
  site: 'https://farnhamseniorhealth.com',
  output: 'hybrid',
  trailingSlash: 'never',
  adapter: node({ mode: 'middleware' }),
  vite: { server: { allowedHosts: true } },
  integrations: [
    tailwind(),
    react(),
    sitemap({
      filter: (page) => !page.includes('/thank-you'),
    }),
  ],
});
