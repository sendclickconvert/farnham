FARNHAM — JIM'S PAGE REWRITES (Batch 2)
========================================
Drop-in replacements for 7 pages. Extract at project root and overwrite.

FILES:
  src/pages/services/high-deductible-medicare-supplement.astro  (estimator deleted, links updated)
  src/pages/services/medicare-supplement.astro                   (title + intro rewritten)
  src/pages/high-deductible-plan-g-worth-it.astro               (sentence deleted, pros/cons rewritten)
  src/pages/high-deductible-plan-g-vs-plan-g.astro              (full rewrite, FAQs deleted)
  src/pages/switch-high-deductible-plan-g-to-plan-g.astro       (full rewrite, bottom section deleted)
  src/pages/medicare-advantage-vs-medigap.astro                  (Medigap first, full rewrite)
  src/pages/medicare-part-d-late-enrollment-penalty.astro        (sentence + FAQs deleted)
  src/pages/medicare-basics.astro                                (Part A/B links deleted, FAQs deleted)

ALSO DELETE THESE PAGES ENTIRELY (Jim requested):
  src/pages/high-deductible-plan-g-deductible-2026.astro
  src/pages/high-deductible-plan-g-carriers.astro
  src/pages/what-is-medicare-part-a.astro
  src/pages/what-is-medicare-part-b.astro

REPLIT COMMAND:
After extracting the zip, also run in the shell:
  rm src/pages/high-deductible-plan-g-deductible-2026.astro
  rm src/pages/high-deductible-plan-g-carriers.astro
  rm src/pages/what-is-medicare-part-a.astro
  rm src/pages/what-is-medicare-part-b.astro
Then: npm run build
