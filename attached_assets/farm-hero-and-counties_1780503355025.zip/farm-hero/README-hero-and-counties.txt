FARNHAM — HERO LEAD FORM + DEEPENED COUNTY PAGES
================================================
Replaces 5 files (extract at project root, overwrite when prompted):
  src/components/Hero.astro                          (homepage hero, now with form)
  src/pages/service-areas/ulster-county.astro        (deepened)
  src/pages/service-areas/dutchess-county.astro      (deepened)
  src/pages/service-areas/orange-county.astro        (deepened)
  src/pages/service-areas/westchester-county.astro   (deepened)

HERO LEAD FORM
- "Get a free, no-obligation Medicare review." Fields: name, phone, ZIP, status
  (turning 65 / on Medicare / exploring). NOT a "do you qualify" quiz — by design.
- Mirrors /contact exactly: same TCPA consent checkbox wording, same no-PHI line,
  posts to FORMS.webhookUrl (data-form="lead"). Until Jim pastes the real CRM
  webhook into site.ts FORMS.webhookUrl, it submits to '#' (same as contact form).
- The headshot moved INTO the form-card header as a small avatar (same AGENT.photo
  path + graceful fallback). The photo is still there, just repositioned. If you
  want it larger/more prominent, say so and it's an easy change.
- TPMO disclaimer remains site-wide (footer + pages). Have Jim's E&O/FMO compliance
  sign off on the consent + disclaimer wording before launch — it's a lead form.

COUNTY PAGES (deepened to ~550-640 words each, distinct local angle per county)
- Ulster: rural provider-freedom (thin MA networks out west)
- Dutchess: hospital-merger network volatility -> Medigap stability
- Orange: geographic spread -> any-provider freedom
- Westchester: MA-saturation -> value of an independent second opinion
