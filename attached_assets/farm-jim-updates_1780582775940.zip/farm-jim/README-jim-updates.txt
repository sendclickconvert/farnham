FARNHAM — JIM FARNHAM CHANGE REQUESTS (Jun 4 2026)
====================================================
Address all four items from Jim's email (Thu 6/4/2026 12:23 PM):

1. FREE → NO COST (site-wide, 20+ replacements)
   Every instance of the word "free" in commercial/service context is now "no cost."
   Untouched: "premium-free" and "freedom" (correct Medicare/general vocabulary).

2. HD PLAN G — NOT "ALL OR NOTHING"
   Hero subhead now leads with "educate first — explain options clearly and show how
   to save money along the way" then positions HD as one option being compared honestly.
   The HD pillar already said "not right for everyone"; homepage now matches that tone.

3. MEDICARE 101 NO-COST CLASSES — highlighted on homepage
   New section after the intro on the homepage: what classes cover, who they're for,
   take-home resources. Links to /events (schedule) and /resources (resource list).

4. RESOURCES PAGE — /resources (NEW PAGE)
   Jim's full curated list of official government Medicare resources, organized into:
   - Core sites (Medicare.gov, SSA, CMS)
   - Enrollment links
   - Coverage & benefits
   - Medigap (Medicare Supplement)
   - Part D
   - Financial help & SHIP
   - Social Security & taxes
   - State sections: New York, Connecticut, New Jersey, Pennsylvania, Florida

FILES IN THIS ZIP (16 files, all drop-in replacements except resources.astro which is new):
  src/components/Hero.astro
  src/components/TrustBar.astro
  src/layouts/BaseLayout.astro
  src/pages/index.astro
  src/pages/events.astro
  src/pages/resources.astro                          ← NEW
  src/pages/medicare-basics.astro
  src/pages/turning-65.astro
  src/pages/new-york-medicare-supplement.astro
  src/pages/connecticut-medicare-supplement.astro
  src/pages/thank-you.astro
  src/pages/medicare-part-d-late-enrollment-penalty.astro
  src/pages/service-areas/ulster-county.astro
  src/pages/service-areas/dutchess-county.astro
  src/pages/service-areas/orange-county.astro
  src/pages/service-areas/westchester-county.astro

TODO (for the team):
  - Add "Resources" to site navigation (site.ts NAV_ITEMS → /resources)
  - Jim's headshot retouched version → drop at public/images/jim-farnham.jpg when ready
  - Wire CRM webhook in site.ts FORMS.webhookUrl (both lead forms use this)
  - TPMO [NUMBER] org/product counts still needed from Jim before launch
